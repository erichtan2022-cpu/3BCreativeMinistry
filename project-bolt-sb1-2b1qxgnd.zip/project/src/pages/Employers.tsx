import { useState } from 'react';
import { Award, Users, TrendingUp, Shield, CheckCircle, Building2, Wrench, Heart, Utensils, Factory, HardHat } from 'lucide-react';
import { supabase, EmployerConsultation } from '../lib/supabase';

export default function Employers() {
  const [formData, setFormData] = useState<EmployerConsultation>({
    company_name: '',
    contact_person: '',
    email: '',
    phone: '',
    industry: '',
    hiring_needs: '',
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const benefits = [
    {
      icon: Award,
      title: 'Highly Skilled Workforce',
      description: 'Access to thoroughly vetted professionals with proven technical skills and international work readiness.',
    },
    {
      icon: TrendingUp,
      title: 'Strong Work Ethic',
      description: 'Indonesian workers are known for their dedication, reliability, and commitment to excellence.',
    },
    {
      icon: Users,
      title: 'Cultural Adaptability',
      description: 'Our candidates receive comprehensive cultural training, ensuring smooth integration into your workplace.',
    },
    {
      icon: Shield,
      title: 'Complete Compliance',
      description: 'We handle all legal requirements, documentation, and regulatory compliance for international hiring.',
    },
  ];

  const process = [
    {
      step: '1',
      title: 'Submit Your Requirements',
      description: 'Tell us about your hiring needs, including job specifications, qualifications, and timeline.',
    },
    {
      step: '2',
      title: 'Candidate Sourcing & Screening',
      description: 'We identify and thoroughly assess candidates who match your specific requirements.',
    },
    {
      step: '3',
      title: 'Candidate Presentation',
      description: 'Review detailed profiles of pre-qualified candidates for your consideration.',
    },
    {
      step: '4',
      title: 'Training & Preparation',
      description: 'Selected candidates undergo job-specific training and cultural orientation.',
    },
    {
      step: '5',
      title: 'Deployment & Integration',
      description: 'We manage all logistics and provide ongoing support for successful placement.',
    },
  ];

  const industries = [
    { icon: HardHat, name: 'Construction & Engineering' },
    { icon: Heart, name: 'Healthcare & Medical' },
    { icon: Utensils, name: 'Hospitality & Tourism' },
    { icon: Factory, name: 'Manufacturing & Production' },
    { icon: Wrench, name: 'Oil & Gas' },
    { icon: Building2, name: 'Facilities Management' },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const { error: submitError } = await supabase
        .from('employer_consultations')
        .insert([formData]);

      if (submitError) throw submitError;

      setSubmitted(true);
    } catch (err) {
      setError('An error occurred. Please try again.');
      console.error('Error submitting form:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen">
      <section
        className="relative h-[450px] bg-cover bg-center flex items-center"
        style={{
          backgroundImage: 'linear-gradient(rgba(0, 134, 206, 0.85), rgba(0, 134, 206, 0.85)), url(https://images.pexels.com/photos/3184338/pexels-photo-3184338.jpeg?auto=compress&cs=tinysrgb&w=1920)',
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
          <h1 className="text-5xl md:text-6xl font-bold mb-4">Hire Top Indonesian Talent</h1>
          <p className="text-xl md:text-2xl mb-8 max-w-4xl mx-auto">
            Access a pool of skilled, dedicated, and culturally prepared Indonesian professionals
            ready to contribute to your organization's success
          </p>
          <a
            href="#consultation"
            className="bg-[#E5B022] text-gray-900 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-[#d4a520] transition-all transform hover:scale-105 shadow-lg inline-block"
          >
            Request a Consultation
          </a>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Why Hire from Indonesia?</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Indonesia offers one of the world's largest and most talented workforces, combining
              technical excellence with cultural adaptability
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <div
                key={index}
                className="bg-gray-50 rounded-xl p-6 hover:shadow-lg transition-shadow text-center"
              >
                <div className="w-16 h-16 bg-[#0086CE] rounded-full flex items-center justify-center mx-auto mb-4">
                  <benefit.icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{benefit.title}</h3>
                <p className="text-gray-700 leading-relaxed">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Process for Employers</h2>
            <p className="text-xl text-gray-600">
              A streamlined, professional approach to international recruitment
            </p>
          </div>
          <div className="relative">
            <div className="absolute top-1/2 left-0 right-0 h-1 bg-[#0086CE] opacity-20 hidden lg:block"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 relative">
              {process.map((item, index) => (
                <div key={index} className="relative">
                  <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow h-full">
                    <div className="w-16 h-16 bg-[#E5B022] rounded-full flex items-center justify-center mx-auto mb-4 text-white text-2xl font-bold relative z-10">
                      {item.step}
                    </div>
                    <h3 className="text-lg font-bold text-gray-900 mb-3 text-center">{item.title}</h3>
                    <p className="text-gray-700 text-sm text-center leading-relaxed">{item.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Industries We Serve</h2>
            <p className="text-xl text-gray-600">
              Providing qualified professionals across diverse sectors
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
            {industries.map((industry, index) => (
              <div
                key={index}
                className="bg-gray-50 rounded-xl p-6 hover:bg-[#0086CE] hover:text-white transition-colors group text-center"
              >
                <industry.icon className="h-10 w-10 mx-auto mb-3 text-[#0086CE] group-hover:text-white" />
                <p className="font-semibold text-sm">{industry.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="consultation" className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {submitted ? (
            <div className="bg-white rounded-xl shadow-lg p-8 text-center">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="h-10 w-10 text-green-600" />
              </div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Thank You for Your Interest!</h2>
              <p className="text-gray-600 mb-8 text-lg">
                We have received your consultation request. Our team will review your requirements
                and contact you within 24 hours to discuss how we can support your hiring needs.
              </p>
              <button
                onClick={() => setSubmitted(false)}
                className="bg-[#0086CE] text-white px-8 py-3 rounded-lg font-semibold hover:bg-[#006ba3] transition-colors"
              >
                Submit Another Request
              </button>
            </div>
          ) : (
            <div className="bg-white rounded-xl shadow-lg p-8">
              <div className="text-center mb-8">
                <h2 className="text-4xl font-bold text-gray-900 mb-4">Request a Consultation</h2>
                <p className="text-gray-600 text-lg">
                  Tell us about your hiring needs and we'll connect you with the right talent
                </p>
              </div>
              {error && (
                <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
                  {error}
                </div>
              )}
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Company Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.company_name}
                      onChange={(e) => setFormData({ ...formData, company_name: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0086CE]"
                      placeholder="Your company name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Contact Person *
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.contact_person}
                      onChange={(e) => setFormData({ ...formData, contact_person: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0086CE]"
                      placeholder="Your full name"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0086CE]"
                      placeholder="your.email@company.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                    <input
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0086CE]"
                      placeholder="+1 xxx xxx xxxx"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Industry</label>
                  <select
                    value={formData.industry}
                    onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0086CE]"
                  >
                    <option value="">Select your industry</option>
                    <option value="Construction & Engineering">Construction & Engineering</option>
                    <option value="Healthcare & Medical">Healthcare & Medical</option>
                    <option value="Hospitality & Tourism">Hospitality & Tourism</option>
                    <option value="Manufacturing & Production">Manufacturing & Production</option>
                    <option value="Oil & Gas">Oil & Gas</option>
                    <option value="Facilities Management">Facilities Management</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Hiring Needs *
                  </label>
                  <textarea
                    required
                    value={formData.hiring_needs}
                    onChange={(e) => setFormData({ ...formData, hiring_needs: e.target.value })}
                    rows={6}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0086CE]"
                    placeholder="Please describe your hiring requirements, including positions needed, qualifications, number of workers, timeline, and any specific requirements..."
                  />
                </div>
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-[#E5B022] text-gray-900 py-4 rounded-lg text-lg font-semibold hover:bg-[#d4a520] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? 'Submitting...' : 'Submit Consultation Request'}
                </button>
              </form>
            </div>
          )}
        </div>
      </section>

      <section className="py-16 bg-[#0086CE]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center text-white">
            <div>
              <p className="text-5xl font-bold mb-2">10,000+</p>
              <p className="text-lg">Workers Successfully Placed</p>
            </div>
            <div>
              <p className="text-5xl font-bold mb-2">500+</p>
              <p className="text-lg">International Employers Served</p>
            </div>
            <div>
              <p className="text-5xl font-bold mb-2">98%</p>
              <p className="text-lg">Client Satisfaction Rate</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
