import { Users, GraduationCap, Globe, CheckCircle, ArrowRight, Award } from 'lucide-react';

interface HomeProps {
  onNavigate: (page: string) => void;
}

export default function Home({ onNavigate }: HomeProps) {
  const services = [
    {
      icon: Users,
      title: 'Talent Recruitment',
      description: 'Finding the right fit through comprehensive screening and matching processes tailored to employer requirements.',
      link: 'services',
    },
    {
      icon: GraduationCap,
      title: 'Skills Training',
      description: 'Preparing candidates for global standards with language proficiency, technical skills, and cultural orientation programs.',
      link: 'services',
    },
    {
      icon: Globe,
      title: 'Global Placement',
      description: 'Seamless transition abroad with complete support for visa processing, documentation, and post-placement assistance.',
      link: 'services',
    },
  ];

  const steps = [
    { number: '1', title: 'Apply', description: 'Submit your application and profile' },
    { number: '2', title: 'Get Assessed', description: 'Complete skills and language evaluation' },
    { number: '3', title: 'Get Trained', description: 'Receive comprehensive training' },
    { number: '4', title: 'Get Placed', description: 'Start your global career journey' },
  ];

  const testimonials = [
    {
      quote: 'PT Solusi Global Karier transformed my career. Within 3 months, I was working as a nurse in Singapore with excellent support throughout the process.',
      name: 'Siti Nurhaliza',
      role: 'Registered Nurse',
      location: 'Singapore',
    },
    {
      quote: 'The training program prepared me perfectly for my role in Dubai. The team supported me every step of the way, from documentation to arrival.',
      name: 'Ahmad Rizki',
      role: 'Civil Engineer',
      location: 'United Arab Emirates',
    },
    {
      quote: 'I never thought I could work in Japan, but they made it possible. The language and cultural training was invaluable for my success here.',
      name: 'Dewi Lestari',
      role: 'Hotel Supervisor',
      location: 'Japan',
    },
  ];

  const partners = [
    { name: 'Japan', flag: '🇯🇵' },
    { name: 'Singapore', flag: '🇸🇬' },
    { name: 'UAE', flag: '🇦🇪' },
    { name: 'Malaysia', flag: '🇲🇾' },
    { name: 'Saudi Arabia', flag: '🇸🇦' },
  ];

  return (
    <div className="min-h-screen">
      <section
        className="relative h-[600px] bg-cover bg-center flex items-center"
        style={{
          backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=1920)',
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
          <div className="mb-6">
            <h1 className="text-5xl md:text-6xl font-bold mb-4">PT Solusi Global Karier</h1>
            <p className="text-2xl md:text-3xl mb-8 text-[#E5B022] font-semibold">
              Transforming Indonesian Potential into Global Impact
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => onNavigate('jobs')}
              className="bg-[#E5B022] text-gray-900 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-[#d4a520] transition-all transform hover:scale-105 shadow-lg"
            >
              Find Your Global Career
            </button>
            <button
              onClick={() => onNavigate('employers')}
              className="bg-transparent border-2 border-[#0086CE] text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-[#0086CE] transition-all transform hover:scale-105"
            >
              Partner With Us
            </button>
          </div>
        </div>
      </section>

      <section className="bg-white py-8 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-center text-gray-600 mb-6 font-semibold">Trusted By International Partners</p>
          <div className="flex justify-center items-center gap-8 flex-wrap">
            {partners.map((partner) => (
              <div key={partner.name} className="flex flex-col items-center">
                <span className="text-5xl mb-2">{partner.flag}</span>
                <span className="text-sm text-gray-600 font-medium">{partner.name}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Our Comprehensive Solutions</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              End-to-end support for your international career journey
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div
                key={index}
                className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow border-t-4 border-[#0086CE]"
              >
                <div className="w-16 h-16 bg-[#0086CE] rounded-full flex items-center justify-center mb-6">
                  <service.icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">{service.title}</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">{service.description}</p>
                <button
                  onClick={() => onNavigate(service.link)}
                  className="text-[#0086CE] font-semibold hover:text-[#E5B022] transition-colors inline-flex items-center group"
                >
                  Learn More
                  <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">How It Works</h2>
            <p className="text-xl text-gray-600">Your journey to a global career in four simple steps</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="text-center relative">
                <div className="w-20 h-20 bg-[#E5B022] rounded-full flex items-center justify-center text-white text-3xl font-bold mx-auto mb-4 shadow-lg">
                  {step.number}
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
                {index < steps.length - 1 && (
                  <div className="hidden md:block absolute top-10 left-[60%] w-[80%] h-0.5 bg-[#0086CE] opacity-30"></div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Success Stories</h2>
            <p className="text-xl text-gray-600">Hear from professionals who transformed their careers</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow">
                <Award className="h-10 w-10 text-[#E5B022] mb-4" />
                <p className="text-gray-700 mb-6 leading-relaxed italic">"{testimonial.quote}"</p>
                <div className="border-t pt-4">
                  <p className="font-bold text-gray-900">{testimonial.name}</p>
                  <p className="text-sm text-gray-600">{testimonial.role}</p>
                  <p className="text-sm text-[#0086CE] font-semibold">{testimonial.location}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-[#0086CE] py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">Ready to Transform Your Career?</h2>
          <p className="text-xl text-white mb-8 opacity-90">
            Join thousands of Indonesians who have successfully built international careers
          </p>
          <button
            onClick={() => onNavigate('jobs')}
            className="bg-[#E5B022] text-gray-900 px-10 py-4 rounded-lg text-lg font-semibold hover:bg-[#d4a520] transition-all transform hover:scale-105 shadow-lg inline-flex items-center"
          >
            Explore Opportunities
            <ArrowRight className="ml-2 h-5 w-5" />
          </button>
        </div>
      </section>
    </div>
  );
}
