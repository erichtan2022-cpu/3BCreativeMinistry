import { Users, Search, CheckCircle, GraduationCap, BookOpen, Languages, Globe, FileText, Plane, HeadphonesIcon, Award } from 'lucide-react';

export default function Services() {
  const recruitmentSteps = [
    {
      icon: Search,
      title: 'Candidate Sourcing',
      description: 'We identify and attract top talent through our extensive network and targeted recruitment campaigns.',
    },
    {
      icon: CheckCircle,
      title: 'Screening & Assessment',
      description: 'Rigorous evaluation of skills, qualifications, and cultural fit to ensure quality matches.',
    },
    {
      icon: Users,
      title: 'Matching & Placement',
      description: 'Precise alignment of candidate profiles with employer requirements for optimal placement success.',
    },
  ];

  const trainingModules = [
    {
      icon: Languages,
      title: 'Language Proficiency',
      description: 'Comprehensive English, Japanese, Arabic, or Mandarin language training tailored to industry requirements.',
    },
    {
      icon: Award,
      title: 'Technical Skills Development',
      description: 'Industry-specific training programs covering technical competencies and professional certifications.',
    },
    {
      icon: Globe,
      title: 'Cultural Orientation',
      description: 'Preparation for working and living abroad, including cultural awareness and workplace etiquette.',
    },
    {
      icon: BookOpen,
      title: 'Soft Skills Training',
      description: 'Communication, teamwork, problem-solving, and leadership skills essential for global success.',
    },
  ];

  const placementServices = [
    {
      icon: FileText,
      title: 'Documentation Assistance',
      description: 'Complete support with visa applications, work permits, medical examinations, and all required paperwork.',
    },
    {
      icon: Plane,
      title: 'Travel Arrangements',
      description: 'Coordination of flights, airport transfers, and initial accommodation to ensure a smooth transition.',
    },
    {
      icon: HeadphonesIcon,
      title: 'Pre-Departure Briefing',
      description: 'Comprehensive orientation covering job expectations, local regulations, and emergency contacts.',
    },
    {
      icon: Users,
      title: 'Post-Placement Support',
      description: 'Ongoing assistance after arrival, including settling-in support and performance monitoring.',
    },
  ];

  return (
    <div className="min-h-screen">
      <section
        className="relative h-[350px] bg-cover bg-center flex items-center"
        style={{
          backgroundImage: 'linear-gradient(rgba(229, 176, 34, 0.85), rgba(229, 176, 34, 0.85)), url(https://images.pexels.com/photos/3184639/pexels-photo-3184639.jpeg?auto=compress&cs=tinysrgb&w=1920)',
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
          <h1 className="text-5xl md:text-6xl font-bold mb-4">Our Comprehensive Solutions</h1>
          <p className="text-xl md:text-2xl">
            End-to-end services for successful international career transitions
          </p>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
            <div>
              <div className="flex items-center mb-6">
                <div className="w-16 h-16 bg-[#0086CE] rounded-full flex items-center justify-center mr-4">
                  <Users className="h-8 w-8 text-white" />
                </div>
                <h2 className="text-4xl font-bold text-gray-900">Talent Recruitment</h2>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed mb-8">
                Our talent recruitment service connects Indonesian professionals with international employers
                through a meticulous process designed to ensure perfect matches. We understand both the needs
                of employers and the aspirations of candidates, creating successful long-term placements.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed mb-8">
                With over 15 years of experience, we have developed an extensive network of partners across
                multiple industries and countries. Our proven methodology ensures that every placement is
                based on thorough assessment, transparent communication, and mutual benefit.
              </p>
              <div className="space-y-6">
                {recruitmentSteps.map((step, index) => (
                  <div key={index} className="flex items-start">
                    <div className="w-12 h-12 bg-[#E5B022] rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                      <step.icon className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900 mb-2">{step.title}</h3>
                      <p className="text-gray-700">{step.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Talent Recruitment"
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-[#0086CE] text-white p-6 rounded-xl shadow-xl max-w-xs">
                <p className="text-3xl font-bold mb-1">10,000+</p>
                <p className="text-sm">Successful Placements</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1 relative">
              <img
                src="https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Workforce Training"
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute -bottom-6 -right-6 bg-[#E5B022] text-white p-6 rounded-xl shadow-xl max-w-xs">
                <p className="text-3xl font-bold mb-1">50+</p>
                <p className="text-sm">Training Programs Available</p>
              </div>
            </div>
            <div className="order-1 lg:order-2">
              <div className="flex items-center mb-6">
                <div className="w-16 h-16 bg-[#0086CE] rounded-full flex items-center justify-center mr-4">
                  <GraduationCap className="h-8 w-8 text-white" />
                </div>
                <h2 className="text-4xl font-bold text-gray-900">Workforce Training</h2>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed mb-8">
                Our comprehensive training programs prepare candidates to meet and exceed global standards.
                We combine theoretical knowledge with practical skills, ensuring that every graduate is
                confident, competent, and ready for international employment.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed mb-8">
                Training is conducted at our state-of-the-art facilities by certified instructors with
                international experience. We continuously update our curriculum to reflect current industry
                demands and emerging global trends.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {trainingModules.map((module, index) => (
                  <div key={index} className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow">
                    <div className="w-12 h-12 bg-[#0086CE] rounded-lg flex items-center justify-center mb-4">
                      <module.icon className="h-6 w-6 text-white" />
                    </div>
                    <h3 className="text-lg font-bold text-gray-900 mb-2">{module.title}</h3>
                    <p className="text-gray-700 text-sm">{module.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="flex items-center mb-6">
                <div className="w-16 h-16 bg-[#0086CE] rounded-full flex items-center justify-center mr-4">
                  <Globe className="h-8 w-8 text-white" />
                </div>
                <h2 className="text-4xl font-bold text-gray-900">International Placement</h2>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed mb-8">
                We handle every aspect of the international placement process, ensuring a seamless transition
                from Indonesia to your destination country. Our comprehensive support covers all documentation,
                travel logistics, and post-arrival assistance.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed mb-8">
                Our experienced team navigates complex visa procedures, coordinates with international partners,
                and provides continuous support to ensure your successful integration into your new role and
                environment. We remain your trusted partner throughout your international career journey.
              </p>
              <div className="space-y-6">
                {placementServices.map((service, index) => (
                  <div key={index} className="bg-gray-50 rounded-xl p-6 border-l-4 border-[#E5B022]">
                    <div className="flex items-start">
                      <div className="w-12 h-12 bg-[#0086CE] rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                        <service.icon className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-gray-900 mb-2">{service.title}</h3>
                        <p className="text-gray-700">{service.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/3184306/pexels-photo-3184306.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="International Placement"
                className="rounded-2xl shadow-2xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-[#0086CE] text-white p-6 rounded-xl shadow-xl max-w-xs">
                <p className="text-3xl font-bold mb-1">20+</p>
                <p className="text-sm">Partner Countries Worldwide</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-[#0086CE]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">Ready to Begin Your Journey?</h2>
          <p className="text-xl text-white mb-8 opacity-90 max-w-3xl mx-auto">
            Let us guide you through every step of your international career path with our
            comprehensive services and dedicated support team.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="#jobs"
              className="bg-[#E5B022] text-gray-900 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-[#d4a520] transition-all transform hover:scale-105 shadow-lg inline-block"
            >
              View Job Openings
            </a>
            <a
              href="#contact"
              className="bg-white text-[#0086CE] px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-all transform hover:scale-105 shadow-lg inline-block"
            >
              Contact Us
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
