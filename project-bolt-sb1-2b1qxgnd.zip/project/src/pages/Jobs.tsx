import { useState, useEffect } from 'react';
import { Search, MapPin, Building2, Briefcase, DollarSign, ArrowRight, Filter } from 'lucide-react';
import { supabase, JobOpening } from '../lib/supabase';

export default function Jobs() {
  const [jobs, setJobs] = useState<JobOpening[]>([]);
  const [filteredJobs, setFilteredJobs] = useState<JobOpening[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedJob, setSelectedJob] = useState<JobOpening | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCountry, setSelectedCountry] = useState('all');
  const [selectedIndustry, setSelectedIndustry] = useState('all');
  const [selectedJobType, setSelectedJobType] = useState('all');

  useEffect(() => {
    fetchJobs();
  }, []);

  useEffect(() => {
    filterJobs();
  }, [jobs, searchTerm, selectedCountry, selectedIndustry, selectedJobType]);

  const fetchJobs = async () => {
    try {
      const { data, error } = await supabase
        .from('job_openings')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setJobs(data || []);
    } catch (error) {
      console.error('Error fetching jobs:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterJobs = () => {
    let filtered = [...jobs];

    if (searchTerm) {
      filtered = filtered.filter(
        (job) =>
          job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          job.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
          job.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (selectedCountry !== 'all') {
      filtered = filtered.filter((job) => job.country === selectedCountry);
    }

    if (selectedIndustry !== 'all') {
      filtered = filtered.filter((job) => job.industry === selectedIndustry);
    }

    if (selectedJobType !== 'all') {
      filtered = filtered.filter((job) => job.job_type === selectedJobType);
    }

    setFilteredJobs(filtered);
  };

  const countries = ['all', ...Array.from(new Set(jobs.map((job) => job.country)))];
  const industries = ['all', ...Array.from(new Set(jobs.map((job) => job.industry)))];
  const jobTypes = ['all', ...Array.from(new Set(jobs.map((job) => job.job_type)))];

  if (selectedJob) {
    return <JobDetailView job={selectedJob} onBack={() => setSelectedJob(null)} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <section className="bg-[#0086CE] py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
          <h1 className="text-5xl md:text-6xl font-bold mb-4">Current Global Opportunities</h1>
          <p className="text-xl md:text-2xl mb-8">
            Discover your next international career opportunity
          </p>
          <div className="max-w-2xl mx-auto">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                placeholder="Search by job title, company, or keywords..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-4 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-[#E5B022]"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-xl shadow-md p-6 mb-8">
            <div className="flex items-center mb-4">
              <Filter className="h-5 w-5 text-[#0086CE] mr-2" />
              <h2 className="text-xl font-bold text-gray-900">Filter Opportunities</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Country</label>
                <select
                  value={selectedCountry}
                  onChange={(e) => setSelectedCountry(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0086CE]"
                >
                  {countries.map((country) => (
                    <option key={country} value={country}>
                      {country === 'all' ? 'All Countries' : country}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Industry</label>
                <select
                  value={selectedIndustry}
                  onChange={(e) => setSelectedIndustry(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0086CE]"
                >
                  {industries.map((industry) => (
                    <option key={industry} value={industry}>
                      {industry === 'all' ? 'All Industries' : industry}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Job Type</label>
                <select
                  value={selectedJobType}
                  onChange={(e) => setSelectedJobType(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0086CE]"
                >
                  {jobTypes.map((type) => (
                    <option key={type} value={type}>
                      {type === 'all' ? 'All Job Types' : type}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {loading ? (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#0086CE] mx-auto"></div>
              <p className="text-gray-600 mt-4">Loading opportunities...</p>
            </div>
          ) : filteredJobs.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-xl shadow-md">
              <p className="text-gray-600 text-lg">No opportunities found matching your criteria.</p>
              <p className="text-gray-500 mt-2">Try adjusting your filters or search terms.</p>
            </div>
          ) : (
            <div>
              <div className="mb-6">
                <p className="text-gray-600">
                  Showing <span className="font-semibold text-[#0086CE]">{filteredJobs.length}</span>{' '}
                  {filteredJobs.length === 1 ? 'opportunity' : 'opportunities'}
                </p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredJobs.map((job) => (
                  <div
                    key={job.id}
                    className="bg-white rounded-xl shadow-md hover:shadow-xl transition-shadow p-6 cursor-pointer border-t-4 border-[#0086CE]"
                    onClick={() => setSelectedJob(job)}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div className="w-12 h-12 bg-[#0086CE] rounded-lg flex items-center justify-center flex-shrink-0">
                        <Briefcase className="h-6 w-6 text-white" />
                      </div>
                      <span className="bg-[#E5B022] text-white text-xs font-semibold px-3 py-1 rounded-full">
                        {job.job_type}
                      </span>
                    </div>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{job.title}</h3>
                    <div className="space-y-2 mb-4">
                      <div className="flex items-center text-gray-600 text-sm">
                        <Building2 className="h-4 w-4 mr-2 flex-shrink-0" />
                        <span className="truncate">{job.company}</span>
                      </div>
                      <div className="flex items-center text-gray-600 text-sm">
                        <MapPin className="h-4 w-4 mr-2 flex-shrink-0" />
                        <span>{job.location}, {job.country}</span>
                      </div>
                      {job.salary_range && (
                        <div className="flex items-center text-gray-600 text-sm">
                          <DollarSign className="h-4 w-4 mr-2 flex-shrink-0" />
                          <span>{job.salary_range}</span>
                        </div>
                      )}
                    </div>
                    <div className="mb-4">
                      <span className="inline-block bg-gray-100 text-gray-700 text-xs px-3 py-1 rounded-full">
                        {job.industry}
                      </span>
                    </div>
                    <p className="text-gray-600 text-sm mb-4 line-clamp-3">{job.description}</p>
                    <button className="w-full bg-[#0086CE] text-white py-3 rounded-lg font-semibold hover:bg-[#006ba3] transition-colors inline-flex items-center justify-center group">
                      View Details & Apply
                      <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}

function JobDetailView({ job, onBack }: { job: JobOpening; onBack: () => void }) {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    coverLetter: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-xl shadow-lg p-8 text-center">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <svg className="h-10 w-10 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Application Submitted Successfully!</h2>
            <p className="text-gray-600 mb-8">
              Thank you for applying to {job.title} at {job.company}. Our team will review your application
              and contact you within 3-5 business days.
            </p>
            <button
              onClick={onBack}
              className="bg-[#0086CE] text-white px-8 py-3 rounded-lg font-semibold hover:bg-[#006ba3] transition-colors"
            >
              Browse More Opportunities
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <button
          onClick={onBack}
          className="mb-6 text-[#0086CE] font-semibold hover:text-[#006ba3] transition-colors inline-flex items-center"
        >
          <ArrowRight className="h-4 w-4 mr-2 rotate-180" />
          Back to All Opportunities
        </button>

        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="bg-[#0086CE] text-white p-8">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h1 className="text-4xl font-bold mb-2">{job.title}</h1>
                <div className="flex flex-wrap gap-4 text-lg">
                  <div className="flex items-center">
                    <Building2 className="h-5 w-5 mr-2" />
                    {job.company}
                  </div>
                  <div className="flex items-center">
                    <MapPin className="h-5 w-5 mr-2" />
                    {job.location}, {job.country}
                  </div>
                </div>
              </div>
              <span className="bg-[#E5B022] text-white px-4 py-2 rounded-full text-sm font-semibold">
                {job.job_type}
              </span>
            </div>
            {job.salary_range && (
              <div className="flex items-center text-lg">
                <DollarSign className="h-5 w-5 mr-2" />
                {job.salary_range}
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 p-8">
            <div className="lg:col-span-2">
              <div className="mb-8">
                <h2 className="text-2xl font-bold text-gray-900 mb-4">Job Description</h2>
                <div className="prose max-w-none text-gray-700 leading-relaxed whitespace-pre-wrap">
                  {job.description}
                </div>
              </div>

              <div className="bg-gray-50 rounded-xl p-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Apply for this Position</h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Full Name *</label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0086CE]"
                      placeholder="Your full name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Email Address *</label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0086CE]"
                      placeholder="your.email@example.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number *</label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0086CE]"
                      placeholder="+62 xxx xxxx xxxx"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Cover Letter *</label>
                    <textarea
                      required
                      value={formData.coverLetter}
                      onChange={(e) => setFormData({ ...formData, coverLetter: e.target.value })}
                      rows={6}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0086CE]"
                      placeholder="Tell us why you're interested in this position..."
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full bg-[#E5B022] text-gray-900 py-4 rounded-lg text-lg font-semibold hover:bg-[#d4a520] transition-colors"
                  >
                    Submit Application
                  </button>
                </form>
              </div>
            </div>

            <div className="lg:col-span-1">
              <div className="bg-gray-50 rounded-xl p-6 sticky top-6">
                <h3 className="text-xl font-bold text-gray-900 mb-4">Job Details</h3>
                <div className="space-y-4">
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Industry</p>
                    <p className="font-semibold text-gray-900">{job.industry}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Job Type</p>
                    <p className="font-semibold text-gray-900">{job.job_type}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Location</p>
                    <p className="font-semibold text-gray-900">{job.location}</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600 mb-1">Country</p>
                    <p className="font-semibold text-gray-900">{job.country}</p>
                  </div>
                  {job.salary_range && (
                    <div>
                      <p className="text-sm text-gray-600 mb-1">Salary Range</p>
                      <p className="font-semibold text-gray-900">{job.salary_range}</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
