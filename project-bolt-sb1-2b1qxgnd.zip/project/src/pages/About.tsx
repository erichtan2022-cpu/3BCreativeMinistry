import { Target, Eye, Award, GraduationCap, Globe, HeartHandshake } from 'lucide-react';

export default function About() {
  const values = [
    {
      icon: Award,
      title: 'Expert Guidance',
      description: 'Over 15 years of experience in international recruitment and placement across multiple countries and industries.',
    },
    {
      icon: GraduationCap,
      title: 'Comprehensive Training Programs',
      description: 'Industry-leading training facilities and certified instructors ensuring candidates meet global standards.',
    },
    {
      icon: Globe,
      title: 'Strong Global Network',
      description: 'Partnerships with leading employers across Asia, Middle East, and beyond for diverse opportunities.',
    },
    {
      icon: HeartHandshake,
      title: 'End-to-End Support',
      description: 'From application to arrival and beyond, we support every step of your international career journey.',
    },
  ];

  const team = [
    {
      name: 'Mr. Fakir Chand',
      role: 'Chief Executive Officer',
      image: 'https://i.imgur.com/c7kxKMJ.jpeg',
      description: '20+ years in international recruitment',
    },
    {
      name: 'Mr. Heinrich Tan',
      role: 'Director of Training & Development',
      image: 'https://i.imgur.com/LB4pknM.jpeg',
      description: 'Expert in workforce development programs',
    },
    {
      name: 'Mrs. Alisa',
      role: 'Head of Global Partnerships',
      image: 'https://i.imgur.com/aLEbFQH.jpeg',
      description: 'Established networks in 15+ countries',
    },
    {
      name: 'Mr. Neeraj Chand',
      role: 'Director of Operations',
      image: 'https://i.imgur.com/F0d8KhQ.jpeg',
      description: 'Streamlining processes for candidate success',
    },
  ];

  const stats = [
    { number: '15+', label: 'Years of Experience' },
    { number: '10,000+', label: 'Successful Placements' },
    { number: '20+', label: 'Partner Countries' },
    { number: '98%', label: 'Client Satisfaction' },
  ];

  return (
    <div className="min-h-screen">
      <section
        className="relative h-[400px] bg-cover bg-center flex items-center"
        style={{
          backgroundImage: 'linear-gradient(rgba(0, 134, 206, 0.85), rgba(0, 134, 206, 0.85)), url(https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=1920)',
        }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
          <h1 className="text-5xl md:text-6xl font-bold mb-4">Our Mission: Your Global Success</h1>
          <p className="text-xl md:text-2xl opacity-95">
            Building bridges between Indonesian talent and global opportunities
          </p>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
            <div>
              <div className="flex items-center mb-6">
                <div className="w-16 h-16 bg-[#0086CE] rounded-full flex items-center justify-center mr-4">
                  <Target className="h-8 w-8 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900">Our Mission</h2>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                To empower Indonesian professionals with world-class training and comprehensive support,
                enabling them to secure rewarding international careers while maintaining the highest
                standards of professional excellence and personal well-being.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed">
                We are committed to being the most trusted bridge between Indonesia's talented workforce
                and global employers seeking dedicated, skilled, and culturally adaptable professionals.
              </p>
            </div>

            <div>
              <div className="flex items-center mb-6">
                <div className="w-16 h-16 bg-[#E5B022] rounded-full flex items-center justify-center mr-4">
                  <Eye className="h-8 w-8 text-white" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900">Our Vision</h2>
              </div>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                To be Southeast Asia's leading international recruitment and training organization,
                recognized for transforming lives through global career opportunities and setting
                the benchmark for ethical, professional, and effective workforce solutions.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed">
                We envision a future where every qualified Indonesian professional has access to
                international opportunities that match their skills, aspirations, and potential for growth.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-20">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-5xl font-bold text-[#0086CE] mb-2">{stat.number}</div>
                <div className="text-gray-600 font-medium">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Why Choose Us?</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We stand out through our commitment to excellence, integrity, and your success
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {values.map((value, index) => (
              <div
                key={index}
                className="bg-gray-50 rounded-xl p-8 hover:shadow-lg transition-shadow border-l-4 border-[#0086CE]"
              >
                <div className="flex items-start">
                  <div className="w-14 h-14 bg-[#0086CE] rounded-lg flex items-center justify-center mr-6 flex-shrink-0">
                    <value.icon className="h-7 w-7 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 mb-3">{value.title}</h3>
                    <p className="text-gray-700 leading-relaxed">{value.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Meet Our Leadership Team</h2>
            <p className="text-xl text-gray-600">
              Experienced professionals dedicated to your success
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, index) => (
              <div
                key={index}
                className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow"
              >
                <div className="aspect-square overflow-hidden bg-gray-200">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{member.name}</h3>
                  <p className="text-[#0086CE] font-semibold mb-3">{member.role}</p>
                  <p className="text-sm text-gray-600">{member.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-[#0086CE]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="mb-6 md:mb-0">
              <h2 className="text-3xl font-bold text-white mb-2">Ready to Start Your Journey?</h2>
              <p className="text-white opacity-90">Let us help you achieve your global career goals</p>
            </div>
            <a
              href="#contact"
              className="bg-[#E5B022] text-gray-900 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-[#d4a520] transition-all transform hover:scale-105 shadow-lg"
            >
              Get Started Today
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
