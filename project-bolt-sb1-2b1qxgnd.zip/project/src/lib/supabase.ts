import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface JobOpening {
  id: string;
  title: string;
  company: string;
  location: string;
  country: string;
  industry: string;
  job_type: string;
  description: string;
  salary_range?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface ContactSubmission {
  name: string;
  email: string;
  phone?: string;
  subject: string;
  message: string;
}

export interface EmployerConsultation {
  company_name: string;
  contact_person: string;
  email: string;
  phone?: string;
  industry?: string;
  hiring_needs: string;
}
