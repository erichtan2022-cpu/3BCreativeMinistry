/*
  # Create Job Openings and Contact Management Tables

  ## Overview
  This migration sets up the database schema for PT Solusi Global Karier's website,
  including job listings, contact submissions, and employer consultation requests.

  ## New Tables
  
  ### 1. `job_openings`
  Stores all available job opportunities for Indonesian workers abroad.
  - `id` (uuid, primary key) - Unique identifier for each job
  - `title` (text) - Job title/position name
  - `company` (text) - Company name or "Confidential Employer"
  - `location` (text) - City/region of the job
  - `country` (text) - Country where the job is located
  - `industry` (text) - Industry sector (e.g., Construction, Healthcare, Hospitality)
  - `job_type` (text) - Employment type (e.g., Full-time, Contract)
  - `description` (text) - Detailed job description and requirements
  - `salary_range` (text) - Salary information (optional)
  - `is_active` (boolean) - Whether the job is currently available
  - `created_at` (timestamptz) - When the job was posted
  - `updated_at` (timestamptz) - Last modification date

  ### 2. `contact_submissions`
  Stores contact form submissions from the Contact Us page.
  - `id` (uuid, primary key) - Unique identifier
  - `name` (text) - Sender's full name
  - `email` (text) - Sender's email address
  - `phone` (text) - Sender's phone number
  - `subject` (text) - Message subject
  - `message` (text) - Message content
  - `created_at` (timestamptz) - When the message was submitted

  ### 3. `employer_consultations`
  Stores consultation requests from employers on the For Employers page.
  - `id` (uuid, primary key) - Unique identifier
  - `company_name` (text) - Employer's company name
  - `contact_person` (text) - Contact person's name
  - `email` (text) - Company email address
  - `phone` (text) - Company phone number
  - `industry` (text) - Industry sector
  - `hiring_needs` (text) - Description of hiring requirements
  - `created_at` (timestamptz) - When the request was submitted

  ## Security
  - Enable RLS on all tables
  - Public read access for job_openings (is_active = true)
  - Authenticated insert access for contact_submissions and employer_consultations
  - Admin-only write access for job_openings
*/

-- Create job_openings table
CREATE TABLE IF NOT EXISTS job_openings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  company text NOT NULL,
  location text NOT NULL,
  country text NOT NULL,
  industry text NOT NULL,
  job_type text NOT NULL DEFAULT 'Full-time',
  description text NOT NULL,
  salary_range text,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create contact_submissions table
CREATE TABLE IF NOT EXISTS contact_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  phone text,
  subject text NOT NULL,
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create employer_consultations table
CREATE TABLE IF NOT EXISTS employer_consultations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_name text NOT NULL,
  contact_person text NOT NULL,
  email text NOT NULL,
  phone text,
  industry text,
  hiring_needs text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE job_openings ENABLE ROW LEVEL SECURITY;
ALTER TABLE contact_submissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE employer_consultations ENABLE ROW LEVEL SECURITY;

-- RLS Policies for job_openings
-- Anyone can view active job openings
CREATE POLICY "Anyone can view active job openings"
  ON job_openings
  FOR SELECT
  USING (is_active = true);

-- RLS Policies for contact_submissions
-- Anyone can insert contact submissions
CREATE POLICY "Anyone can submit contact forms"
  ON contact_submissions
  FOR INSERT
  WITH CHECK (true);

-- RLS Policies for employer_consultations
-- Anyone can insert employer consultation requests
CREATE POLICY "Anyone can submit employer consultations"
  ON employer_consultations
  FOR INSERT
  WITH CHECK (true);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_job_openings_country ON job_openings(country);
CREATE INDEX IF NOT EXISTS idx_job_openings_industry ON job_openings(industry);
CREATE INDEX IF NOT EXISTS idx_job_openings_is_active ON job_openings(is_active);

-- Insert sample job openings
INSERT INTO job_openings (title, company, location, country, industry, job_type, description, salary_range) VALUES
('Civil Engineer', 'Al Habtoor Group', 'Dubai', 'United Arab Emirates', 'Construction', 'Full-time', 'We are seeking experienced Civil Engineers to join our team in Dubai. Responsibilities include overseeing construction projects, ensuring compliance with safety standards, and managing project timelines. Requirements: Bachelor''s degree in Civil Engineering, minimum 3 years experience, proficiency in AutoCAD and project management software.', '$3,500 - $5,000 USD/month'),
('Registered Nurse', 'National Healthcare Group', 'Singapore', 'Singapore', 'Healthcare', 'Full-time', 'Join our world-class healthcare team as a Registered Nurse. You will provide comprehensive patient care, administer medications, and collaborate with medical professionals. Requirements: Valid nursing license, minimum 2 years clinical experience, excellent communication skills, IELTS 6.5 or equivalent.', '$2,800 - $4,200 SGD/month'),
('Hotel Front Desk Supervisor', 'Marriott International', 'Tokyo', 'Japan', 'Hospitality', 'Full-time', 'Lead our front desk team at a prestigious hotel in Tokyo. Responsibilities include managing guest check-in/check-out, handling inquiries, training staff, and ensuring exceptional guest experiences. Requirements: 2+ years in hospitality, fluent English, basic Japanese preferred, strong leadership skills.', '¥280,000 - ¥350,000 JPY/month'),
('Welding Technician', 'PETRONAS', 'Kuala Lumpur', 'Malaysia', 'Oil & Gas', 'Contract', 'Experienced welders needed for oil and gas projects. Perform welding operations, conduct quality checks, and maintain safety protocols. Requirements: Certified welder (ASME/API standards), 5+ years experience, ability to read technical drawings, willingness to work offshore.', 'RM 4,500 - RM 6,500 MYR/month'),
('Restaurant Chef', 'Al Futtaim Group', 'Riyadh', 'Saudi Arabia', 'Hospitality', 'Full-time', 'Join our culinary team as a Chef specializing in international cuisine. Plan menus, supervise kitchen staff, ensure food quality and safety standards. Requirements: Culinary degree or equivalent, 4+ years experience in high-volume restaurants, knowledge of Asian and Western cuisines.', 'SAR 5,000 - SAR 7,000/month'),
('Manufacturing Technician', 'Panasonic Corporation', 'Osaka', 'Japan', 'Manufacturing', 'Full-time', 'Operate and maintain manufacturing equipment in our electronics production facility. Conduct quality control, troubleshoot issues, and follow production schedules. Requirements: Technical diploma, 2+ years in manufacturing, understanding of lean manufacturing principles, basic Japanese language skills.', '¥250,000 - ¥320,000 JPY/month');
